<?php
class Ecomatic_Ajax_Helper_Data extends Mage_Core_Helper_Abstract{
	public function getEnabled() {
		return true;
    }	
}