<?php
class Ecomatic_Collectorbank_Model_Collectorpay extends Mage_Payment_Model_Method_Abstract
{
	protected $_code = 'collectorpay';
	
}
?>
 