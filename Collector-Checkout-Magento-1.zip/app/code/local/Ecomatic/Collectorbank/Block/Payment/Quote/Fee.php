<?php

class Ecomatic_Collectorbank_Block_Payment_Quote_Fee extends Mage_Checkout_Block_Total_Default
{



}
