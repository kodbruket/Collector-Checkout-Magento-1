<?php   
class Ecomatic_Collectorbank_Block_Sales_Order_View_Info extends Mage_Adminhtml_Block_Sales_Order_View_Info
{
}